package proceso;

public class Perro {

    private String nombre;
    private int edad;

    public Perro() {
        this("Sin indicar", 0);
    }

    public Perro(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

}
