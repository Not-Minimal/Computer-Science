package proceso;

public class Guarderia {

    private Perro perro;
    private Gato gato;

    public Guarderia(Perro perro) {
        this.perro = perro;
    }

    public Guarderia(Gato gato) {
        this.gato = gato;
    }

    public void mostrarInformacion(Gato gato) {

        System.out.println("Instancia de Gato:\nNombre: " + gato.getNombre() + " - Raza: " + gato.getRaza());

    }

    public void mostrarInformacion(Perro perro) {
        System.out.println("Instancia de Perro:\nNombre: " + perro.getNombre() + " - Edad: " + perro.getEdad());
    }

    public void mostrarInformacion() {

        if (perro == null) {
            mostrarInformacion(gato);
        } else {
            mostrarInformacion(perro);
        }

    }

}
