package proceso;

public class Main {

    public static void main(String[] args) {

        Perro p = new Perro("Cosmos", 5);
        Guarderia guarderia_1 = new Guarderia(p);
        guarderia_1.mostrarInformacion();

        System.out.println("*********************************");

        Gato g = new Gato("Timmy", "Snowshoe");
        Guarderia guarderia_2 = new Guarderia(g);
        guarderia_2.mostrarInformacion();

    }

}
