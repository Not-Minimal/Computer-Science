package proceso;

public class Gato {

    private String nombre;
    private String raza;

    public Gato() {
        this("Sin indicar", "Sin indicar");
    }

    public Gato(String nombre, String raza) {
        this.nombre = nombre;
        this.raza = raza;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRaza() {
        return raza;
    }

}
