package textos;

public class Textos {

    public static void main(String[] args) {

        System.out.println("********** Ejercicio 1 **********");

        String texto = "Hola mundo";
        int cont = 0;

        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i) == 'a' || texto.charAt(i) == 'e' || texto.charAt(i) == 'i' || texto.charAt(i) == 'o' || texto.charAt(i) == 'u'
                    || texto.charAt(i) == 'A' || texto.charAt(i) == 'E' || texto.charAt(i) == 'I' || texto.charAt(i) == 'O' || texto.charAt(i) == 'U') {
                cont++;
            }
        }

        System.out.println("Texto: " + texto);
        System.out.println("Cantidad de vocales: " + cont);
        System.out.println("Simbolos en total: " + texto.length());

        System.out.print("Inversa: ");
        for (int i = texto.length() - 1; i >= 0; i--) {
            System.out.print(texto.charAt(i));
        }

        System.out.println("\n\n********** Ejercicio 2 **********");

        String texto_a = "EsTo eS uNa cAdEnA";
        String texto_b = "esto ES una CADENA";
        System.out.println("¿Contenidos iguales? (Ignorar mayúsculas y minúsculas): " + texto_a.equalsIgnoreCase(texto_b));

        System.out.println("\n\n********** Ejercicio 3 **********");

        String numeros = "0123456789";
        System.out.println("Texto: " + numeros);
        for (char num : numeros.toCharArray()) {
            System.out.print("[" + num + "] ");
        }

        System.out.println("\n\n********** Ejercicio 4 **********");

        String oracion = "Cambiand[x] text[x] por [x]tr[x]s text[x]s";
        System.out.println("Texto: " + oracion);

        String resultado = oracion.replace("[x]", "o");
        System.out.println("Nuevo: " + resultado);

    }

}
