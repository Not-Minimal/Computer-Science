package lab_scanner_3;

import java.util.Scanner;

public class Lab_Scanner_3 {

    public static void main(String[] args) {
        /*
        3. Ingrese números por teclado indeterminadamente hasta escribir la palabra exit, 
        posteriormente imprima la suma correspondiente a los números pares.
         */

        Scanner entrada = new Scanner(System.in);
        int sumaAcumulada = 0;
        int contador = 0;

        while (true) {
            System.out.print("Ingrese un valor #" + (contador + 1) + ": ");
            contador++;

            if (entrada.hasNextInt())//¿El dato de entrada es un Int válido? - En el caso que no hubiese ningún dato se quedará esperando un valor.
            {
                int valor = entrada.nextInt();//Obteniendo valor ingresado.

                if (valor % 2 == 0)//¿Valor es Par?
                {
                    sumaAcumulada += valor;
                }
            } else if (entrada.hasNext())//¿El dato de entrada es un String válido? - En el caso que no hubiese ningún dato se quedará esperando un valor.
            {
                String texto = entrada.next(); //Obteniendo texto ingresado.

                if (texto.equals("exit"))//¿El texto ingresado es igual a exit?
                {
                    break; //Romper ciclo.
                } else {
                    System.out.println("Valor inválido");
                }
            }
        }

        System.out.println("Suma total pares: " + sumaAcumulada);
    }

}
