package lab_scanner_2;

import java.util.Scanner;

public class Lab_Scanner_2 {

    public static void main(String[] args) {
        /*
        2. Ingrese 5 números por teclado y luego imprima el promedio de ellos.
        */

        Scanner entrada = new Scanner(System.in);

        int sumaAcumulada = 0, cantidadNumeros = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese valor #" + (i + 1) + ":");
            int valor = entrada.nextInt();
            sumaAcumulada += valor;
            cantidadNumeros++;
        }

        /*Como los datos anteriormente declarados son enteros, 
        al realizar una operación dará un resultado truncado(Sin decimal).
        Pero tener presente que se puede castear a float para obtener los decimales(En el caso que hubiesen).
        */
        System.out.println("Promedio: " + ((float)sumaAcumulada/(float)cantidadNumeros));
    }
    
}
