package lab_scanner_4;

import java.util.Scanner;

public class Lab_Scanner_4 {

    public static void main(String[] args) {

        /*
        4. Ingresando cualquier texto Ej: "12 gd2 123 23 23qs exit", 
        imprima la suma total de los números que son válidos("12-123-23"). 
        (Utilice la palabra exit como fin de cadena).
        
        Ingrese por consola directamente -> 12 gd2 123 23 23qs exit
        NO uno por uno -> 
        12
        gd2
        123
        ...
         */
        Scanner entrada = new Scanner(System.in);
        int sumaAcumulada = 0;

        while (true) {

            if (entrada.hasNextInt())//¿El dato de entrada es un Int válido? - En el caso que no hubiese ningún dato se quedará esperando un valor.
            {
                int valor = entrada.nextInt();//Obteniendo valor ingresado.
                sumaAcumulada += valor;

            } else if (entrada.hasNext())//¿El dato de entrada es un String válido? - En el caso que no hubiese ningún dato se quedará esperando un valor.
            {
                String texto = entrada.next(); //Obteniendo texto ingresado.

                if (texto.equals("exit"))//¿El texto ingresado es igual a exit?
                {
                    break; //Romper ciclo.
                }
            }
        }

        System.out.println("Suma total: " + sumaAcumulada);

    }

}
