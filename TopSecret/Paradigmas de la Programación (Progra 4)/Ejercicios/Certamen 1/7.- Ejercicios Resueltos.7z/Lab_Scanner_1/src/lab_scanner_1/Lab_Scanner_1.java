package lab_scanner_1;

import java.util.Scanner;

public class Lab_Scanner_1 {

    public static void main(String[] args) {
        /*
        1. Ingrese 5 números por teclado y luego imprima la suma total.
         */

        Scanner entrada = new Scanner(System.in);

        int sumaAcumulada = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese valor #" + (i + 1) + ":");
            int valor = entrada.nextInt();
            sumaAcumulada += valor;
        }

        System.out.println("Suma Total: " + sumaAcumulada);
    }

}
