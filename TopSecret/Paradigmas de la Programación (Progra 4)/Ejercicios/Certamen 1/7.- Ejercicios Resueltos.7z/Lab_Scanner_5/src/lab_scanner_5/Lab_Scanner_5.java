package lab_scanner_5;

import java.util.Scanner;

public class Lab_Scanner_5 {

    public static void main(String[] args) {

        /*
        5. Ingresando el siguiente texto "100 hola 200 mundo exit",  
        subdivida la frase para imprimir por consola (Utilice la palabra exit como fin de cadena):
        "hola mundo" 
        "100 + 200 = 300" 
        
        Ingrese por consola directamente -> 100 hola 200 mundo exit
        NO uno por uno -> 
        100
        hola
        200
        ...
         */
        Scanner entrada = new Scanner(System.in);

        int primerValor = entrada.nextInt();
        String primerTexto = entrada.next();
        int segundoValor = entrada.nextInt();
        String segundoTexto = entrada.next();

        //No es necesario sacar el exit.
        System.out.println(primerTexto + " " + segundoTexto);
        System.out.println(primerValor + " + " + segundoValor + " = " + (primerValor + segundoValor));

    }

}
