package p3;

import java.util.ArrayList;

public class P3 {

    public static void main(String[] args) {

        ArrayList<Hogar> hogares = new ArrayList<>();

        hogares.add(new Casa(100, 1));
        hogares.add(new Departamento(200, 1));
        hogares.add(new Casa(70, 1));
        hogares.add(new Departamento(40, 1));
        hogares.add(new Casa(200, 2));

        System.out.println(hogares.contains(new Casa(200, 3))); //Es igual a un departamento.
        System.out.println(hogares.contains(new Departamento(40, 1)));

    }

}
