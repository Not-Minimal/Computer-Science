package p3;

public class Departamento extends Hogar {

    public Departamento(int area, int pisos) {
        super(area, pisos);
    }

    public Departamento(int area) {
        super(area, 1);
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Departamento)
            return getPisos() == ((Departamento) o).getPisos()
                    && getArea() == ((Departamento) o).getArea();

        if (o instanceof Casa)
            return getArea() == ((Casa) o).getArea();
        else
            return false;
    }

}
