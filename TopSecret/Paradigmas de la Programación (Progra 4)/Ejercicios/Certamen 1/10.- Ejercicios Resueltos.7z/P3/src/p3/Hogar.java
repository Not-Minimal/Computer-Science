package p3;

public class Hogar {

    private int area;
    private int pisos;

    public Hogar(int area, int pisos) {
        this.area = area;
        this.pisos = pisos;
    }

    public int getArea() {
        return area;
    }

    public int getPisos() {
        return pisos;
    }

}
