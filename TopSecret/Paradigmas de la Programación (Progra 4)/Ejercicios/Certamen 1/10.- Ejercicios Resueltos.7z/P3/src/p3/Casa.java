package p3;

public class Casa extends Hogar {

    public Casa(int area, int pisos) {
        super(area, pisos);
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Casa)
            return getPisos() == ((Casa) o).getPisos()
                    && getArea() == ((Casa) o).getArea();

        if (o instanceof Departamento)
            return getArea() == ((Departamento) o).getArea();
        else
            return false;
    }
}
