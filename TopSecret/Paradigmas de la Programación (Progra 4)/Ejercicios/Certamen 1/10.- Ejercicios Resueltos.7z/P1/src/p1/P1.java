package p1;

import java.util.ArrayList;

public class P1 {

    public static void main(String[] args) {

        ArrayList<Chocolate> chocolates = new ArrayList<>();

        chocolates.add(new Chocolate("Kit Kat", "20/12/2020", 120));
        chocolates.add(new Chocolate("Noka", "20/12/2020", 120));
        chocolates.add(new Chocolate("DeLaffé", "20/12/2020", 120));
        chocolates.add(new Chocolate("Hans Sloane", "20/12/2020", 120));

        System.out.println(chocolates.contains(new Chocolate("Hans Sloane", "10/01/2025", 200)));
        System.out.println(chocolates.contains(new Chocolate("Hans Sloane", "10/01/2025", 120)));

    }

}
