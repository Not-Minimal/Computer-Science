package p1;

public class Chocolate extends Caramelo {
    
    public Chocolate(String marca, String fechaDeVencimiento, int gramos) {
        super(marca, fechaDeVencimiento, gramos);
    }
    
    @Override
    public boolean equals(Object o) {
        if (o instanceof Chocolate) {
            Chocolate aux = (Chocolate) o;
            return getGramos() == aux.getGramos() && getMarca().equals(aux.getMarca());
        } else
            return false;
    }
    
}
