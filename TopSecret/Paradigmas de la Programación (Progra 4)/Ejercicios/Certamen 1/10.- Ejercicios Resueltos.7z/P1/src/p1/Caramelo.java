package p1;

public class Caramelo {

    private String marca;
    private String fechaDeVencimiento;
    private int gramos;

    public Caramelo(String marca, String fechaDeVencimiento, int gramos) {
        this.marca = marca;
        this.fechaDeVencimiento = fechaDeVencimiento;
        this.gramos = gramos;
    }

    public String getMarca() {
        return marca;
    }

    public int getGramos() {
        return gramos;
    }

}
