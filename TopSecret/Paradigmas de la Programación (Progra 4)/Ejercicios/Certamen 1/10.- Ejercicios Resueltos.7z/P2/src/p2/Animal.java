package p2;

public class Animal {

    private String raza;
    private int edad;

    public Animal(String raza, int edad) {
        this.raza = raza;
        this.edad = edad;
    }

    public String getRaza() {
        return raza;
    }

    public int getEdad() {
        return edad;
    }

    public void emitirSonido() {
        System.out.println("...");
    }
}
