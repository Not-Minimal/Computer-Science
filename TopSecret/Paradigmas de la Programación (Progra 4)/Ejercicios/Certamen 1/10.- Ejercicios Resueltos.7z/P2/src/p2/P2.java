package p2;

import java.util.ArrayList;

public class P2 {

    public static void main(String[] args) {

        ArrayList<Animal> animales = new ArrayList<>();

        animales.add(new Gato("Siamés", 8));
        animales.add(new Perro("Bulldog", 10));
        animales.add(new Hamster("Roborowski", 2));
        animales.add(new Gato("Persa", 5));
        animales.add(new Perro("Labrador", 2));
        animales.add(new Gato("Ragdoll", 11));
        animales.add(new Hamster("Dorado", 1));

        System.out.println(animales);

        for (int i = 0; i < animales.size(); i++) {
            Animal aux = animales.get(i);
            aux.emitirSonido();

            if (aux instanceof Gato)
                ((Gato) aux).dormir();

            if (aux instanceof Perro)
                ((Perro) aux).correr();

            if (aux instanceof Hamster)
                ((Hamster) aux).buscarComida();

        }

    }

}
