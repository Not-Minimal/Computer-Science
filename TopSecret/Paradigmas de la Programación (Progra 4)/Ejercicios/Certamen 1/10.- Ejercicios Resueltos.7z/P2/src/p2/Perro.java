package p2;

public class Perro extends Animal {

    public Perro(String raza, int edad) {
        super(raza, edad);
    }

    public void correr() {
        System.out.println("Corriendo...");
    }

    @Override
    public void emitirSonido() {
        System.out.println("Guau");
    }
    
    @Override
    public String toString() {
        return getRaza() + " " + getEdad();
    }
}
