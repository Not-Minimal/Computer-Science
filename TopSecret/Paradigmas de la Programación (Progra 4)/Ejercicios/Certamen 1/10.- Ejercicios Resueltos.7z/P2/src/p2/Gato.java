package p2;

public class Gato extends Animal {

    public Gato(String raza, int edad) {
        super(raza, edad);
    }

    public void dormir() {
        System.out.println("ZzzzZzzzz");
    }

    @Override
    public void emitirSonido() {
        System.out.println("Miau");
    }

    @Override
    public String toString() {
        return getRaza() + " " + getEdad();
    }

}
