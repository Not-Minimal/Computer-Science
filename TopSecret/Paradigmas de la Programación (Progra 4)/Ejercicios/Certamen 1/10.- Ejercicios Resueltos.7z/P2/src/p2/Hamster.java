package p2;

public class Hamster extends Animal {

    public Hamster(String raza, int edad) {
        super(raza, edad);
    }

    public void buscarComida() {
        System.out.println("buscando Comida...");
    }
    
    @Override
    public void emitirSonido() {
        System.out.println("GrrGGrrr");
    }

    @Override
    public String toString() {
        return getRaza() + " " + getEdad();
    }
}
