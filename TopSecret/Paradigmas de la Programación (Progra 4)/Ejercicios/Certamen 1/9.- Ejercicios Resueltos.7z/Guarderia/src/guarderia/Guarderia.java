package guarderia;

public class Guarderia {

    private int perros;
    private int gatos;
    private int hamsters;

    public void agregar(int animales, TipoMascota tipo) {
        switch (tipo) {
            case PERRO:
                perros += animales;
                break;
            case GATO:
                gatos += animales;
                break;
            case HAMSTER:
                hamsters += animales;
                break;
        }
    }

    public void retirar(int animales, TipoMascota tipo) {

        switch (tipo) {
            case PERRO:
                perros -= animales;
                break;
            case GATO:
                gatos -= animales;
                break;
            case HAMSTER:
                hamsters -= animales;
                break;
        }

        if (perros < 0) {
            perros = 0;
        } else if (gatos < 0) {
            gatos = 0;
        } else if (hamsters < 0) {
            hamsters = 0;
        }

    }

    public void retirarTodos(TipoMascota tipo) {
        switch (tipo) {
            case PERRO:
                perros = 0;
                break;
            case GATO:
                gatos = 0;
                break;
            case HAMSTER:
                hamsters = 0;
                break;
        }
    }

    public int totalTipo(TipoMascota tipo) {

        int cantidad = 0;

        switch (tipo) {
            case PERRO:
                cantidad = perros;
                break;
            case GATO:
                cantidad = gatos;
                break;
            case HAMSTER:
                cantidad = hamsters;
                break;
        }

        return cantidad;
    }

    public boolean esMayor(TipoMascota tipo) {

        boolean esMayor = false;

        switch (tipo) {
            case PERRO:
                esMayor = perros > gatos && perros > hamsters;
                break;
            case GATO:
                esMayor = gatos > perros && gatos > hamsters;
                break;
            case HAMSTER:
                esMayor = hamsters > gatos && hamsters > perros;
                break;
        }

        return esMayor;
    }

}
