package guarderia;

public enum TipoMascota {
    PERRO,
    GATO,
    HAMSTER
}
