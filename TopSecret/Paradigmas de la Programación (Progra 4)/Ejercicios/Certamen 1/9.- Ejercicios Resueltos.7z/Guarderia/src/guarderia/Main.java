package guarderia;

public class Main {
   
    public static void main(String[] args) {
        Guarderia guarderia = new Guarderia();
        
        guarderia.agregar(10, TipoMascota.GATO);
        guarderia.agregar(5, TipoMascota.PERRO);
        guarderia.agregar(7, TipoMascota.HAMSTER);
        
        
        System.out.println("La cantidad de Gatos es mayor: "+ guarderia.esMayor(TipoMascota.GATO));
        System.out.println("La cantidad de Hamsters es mayor: "+ guarderia.esMayor(TipoMascota.HAMSTER));
        
        System.out.println("***Se retiran 7 Gatos***");
        guarderia.retirar(7, TipoMascota.GATO);
        
        System.out.println("La cantidad de Hamsters es mayor: "+ guarderia.esMayor(TipoMascota.HAMSTER));
        
        System.out.println("***Se retiran todos los Hamsters***");
        guarderia.retirarTodos(TipoMascota.HAMSTER);
        
        System.out.println("La cantidad de Hamsters es mayor: "+ guarderia.esMayor(TipoMascota.HAMSTER));
        System.out.println("La cantidad de Perros es mayor: "+ guarderia.esMayor(TipoMascota.PERRO));
    }
    
}
