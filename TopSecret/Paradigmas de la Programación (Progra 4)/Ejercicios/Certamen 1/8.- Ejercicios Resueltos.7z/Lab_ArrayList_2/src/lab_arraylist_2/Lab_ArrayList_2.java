package lab_arraylist_2;

import java.util.Scanner;

public class Lab_ArrayList_2 {
    
    public static void main(String[] args) {

        /*
        2. Implemente una clase que almacene una serie de valor numéricos.
        Obs. 1: Pida por teclado cada valor.
        Obs. 2: El ciclo termina cuando se ingresa la palabra exit.
        Dentro de su clase implemente:
        • Un método que retorne la suma de todos los números pares.
        • Un método que retorne la suma de todos los números negativos.
        • Un método que retorne una nueva lista con todos los valores inferiores al valor de
        numeroLimite.
        public ArrayList<Integer> obtenerNumerosMenorA(int numeroLimite)
         */
        Scanner entrada = new Scanner(System.in);
        Reales real = new Reales();
        
        while (true) {            
            if (entrada.hasNextInt()) {
                int numero = entrada.nextInt();
                real.addNumero(numero);
            } else {
                String texto = entrada.next();
                
                if (texto.equals("exit")) {
                    break;
                }
            }            
        }
        
        System.out.println("Números: " + real.getNumeros());
        System.out.println("Suma total par: " + real.sumaTotalPar());
        System.out.println("Suma total negativa: " + real.sumaTotalNegativa());
        System.out.println("Números inferiores a(10): " + real.obtenerNumerosMenorA(10));
        
    }
    
}