package lab_arraylist_2;

import java.util.ArrayList;

public class Reales {

    private ArrayList<Integer> numeros;

    public Reales() {
        numeros = new ArrayList<Integer>();
    }

    public void addNumero(int numero)
    {
        numeros.add(numero);
    }
    
    public int sumaTotalPar() {
        int sumaTotal = 0;

        for (int i = 0; i < numeros.size(); i++) {
            if (numeros.get(i) % 2 == 0) {
                sumaTotal += numeros.get(i);
            }
        }

        return sumaTotal;
    }

    public int sumaTotalNegativa() {
        int sumaTotalNegativa = 0;
        for (int i = 0; i < numeros.size(); i++) {
            if (numeros.get(i) < 0) {
                sumaTotalNegativa += numeros.get(i);
            }
        }

        return sumaTotalNegativa;
    }

    public ArrayList<Integer> obtenerNumerosMenorA(int numeroLimite) {
        ArrayList<Integer> numerosInferiores = new ArrayList<Integer>();

        for (int i = 0; i < numeros.size(); i++) {
            if (numeros.get(i) < numeroLimite) {
                numerosInferiores.add(numeros.get(i));
            }
        }

        return numerosInferiores;
    }
    
    public ArrayList<Integer> getNumeros()
    {
        return numeros;
    }
}