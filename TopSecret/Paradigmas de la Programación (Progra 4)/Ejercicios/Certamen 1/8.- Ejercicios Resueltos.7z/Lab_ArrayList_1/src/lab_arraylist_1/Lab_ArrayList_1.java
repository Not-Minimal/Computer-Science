package lab_arraylist_1;

import java.util.ArrayList;
import java.util.Scanner;

public class Lab_ArrayList_1 {

    public static void main(String[] args) {
        /*
        1. Llenar un arrayList de letras e imprimir los valores en orden inverso al que fueron
        ingresados, por ejemplo si ingresó las letras “A”, “B”, “C” deberá imprimir “C”, “B”, “A”.
        Obs. 1: Pida cada letra por teclado.
        Obs. 2: El ciclo finalizará cuando se ingrese la palabra exit.
        • Para el mismo problema, crear una versión en la que en una lista2 los valores
        originales se almacenan en orden inverso.
         */

        Scanner entrada = new Scanner(System.in);
        ArrayList<Character> letras = new ArrayList<Character>();

        while (true) {
            String texto = entrada.next();

            if (texto.equals("exit")) {
                break;
            }

            char letra = texto.charAt(0);
            letras.add(letra);
        }

        System.out.print("Letras: ");
        for (int i = 0; i < letras.size(); i++) {
            System.out.print(letras.get(i) + " ");
        }

        /*
            • Para el mismo problema, crear una versión en la que en una lista2, los valores
            originales se almacenan en orden inverso.
         */
        ArrayList<Character> lista2 = new ArrayList<Character>();

        for (int i = 0; i < letras.size(); i++) {
            lista2.add(0, letras.get(i));
        }

        System.out.println("\nLista 2(Inverso): " + lista2);
    }

}
