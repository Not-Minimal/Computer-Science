package p3_supermercado;

public class Sello
{
    public String tipo;
    
    public Sello(String tipo)
    {
        this.tipo = tipo;
    }
}
