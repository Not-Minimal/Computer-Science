package p3_supermercado;

import java.util.ArrayList;

public class Supermercado {

    protected ArrayList<ProductoAlimenticio> productos;

    public Supermercado() {
        productos = new ArrayList<>();
    }

    public void addProducto(ProductoAlimenticio producto) {
        productos.add(producto);
    }

    public int totalGanancias() {
        int ganancias = 0;

        for (int i = 0; i < productos.size(); i++) {
            ganancias += productos.get(i).getCosto();
        }

        return ganancias;
    }

    public float precioPromedio() {
        if (productos.isEmpty()) {
            return Float.NaN; //Indeterminado
        }
        return (float) (totalGanancias() / productos.size());
    }

    public int precioMasAlto() {
        if (productos.isEmpty()) {
            return 0;
        }

        int precio = productos.get(0).getCosto();

        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getCosto() > precio) {
                precio = productos.get(i).getCosto();
            }
        }

        return precio;
    }

    public int precioMasBajo() {
        if (productos.isEmpty()) {
            return 0;
        }

        int precio = productos.get(0).getCosto();

        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getCosto() < precio) {
                precio = productos.get(i).getCosto();
            }
        }

        return precio;
    }

    public ArrayList<ProductoAlimenticio> getProductosLibreDeSellos() {
        ArrayList<ProductoAlimenticio> productosLibres = new ArrayList<>();

        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).isLibreSellos()) {
                productosLibres.add(productos.get(i));
            }
        }
        return productosLibres;
    }

    public ArrayList<ProductoAlimenticio> getProductosMenosSaludables() {
        int maxSellos = 0;
        ArrayList<ProductoAlimenticio> productosMS = new ArrayList<>();

        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).sellos.size() > maxSellos) {
                maxSellos = productos.get(i).sellos.size();
            }
        }

        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).sellos.size() == maxSellos) {
                productosMS.add(productos.get(i));
            }
        }

        return productosMS;
    }
}
