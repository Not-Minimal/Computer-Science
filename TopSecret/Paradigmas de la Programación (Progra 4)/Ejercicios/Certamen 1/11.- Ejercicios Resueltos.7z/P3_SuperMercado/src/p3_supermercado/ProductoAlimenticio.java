package p3_supermercado;

import java.util.ArrayList;

public class ProductoAlimenticio {
    
    private int costo;
    private String nombre;
    public ArrayList<Sello> sellos;
    
    public ProductoAlimenticio(String nombre, int costo)
    {
        this.nombre = nombre;
        this.costo = costo;
        sellos = new ArrayList<>();
    }

    public int getCosto() {
        return costo;
    }

    public String getNombre() {
        return nombre;
    }
    
    public boolean isLibreSellos()
    {
        return sellos.isEmpty(); // o sellos.size() == 0
    }
    
}
