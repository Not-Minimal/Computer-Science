package p3_supermercado;

import java.util.ArrayList;

public class P3_SuperMercado {

    public static void main(String[] args) {

        Supermercado unimarc = new Supermercado();

        Sello altoAzucares = new Sello("Alto en azúcares");
        Sello altoGrasas = new Sello("Alto en grasas saturadas");
        Sello altoSodio = new Sello("Alto en sodio");
        Sello altoCalorias = new Sello("Alto en calorías");

        ProductoAlimenticio chocapic = new ProductoAlimenticio("Chocapic", 2500);
        chocapic.sellos.add(altoAzucares);
        chocapic.sellos.add(altoCalorias);

        ProductoAlimenticio trix = new ProductoAlimenticio("Trix", 2300);
        trix.sellos.add(altoAzucares);
        trix.sellos.add(altoCalorias);

        ProductoAlimenticio svelty = new ProductoAlimenticio("Svelty", 4590);

        ProductoAlimenticio nido = new ProductoAlimenticio("Leche Nido", 5000);

        ProductoAlimenticio mantequillaS = new ProductoAlimenticio("Mantequilla Soprole", 1869);
        mantequillaS.sellos.add(altoGrasas);
        mantequillaS.sellos.add(altoCalorias);

        ProductoAlimenticio rocklets = new ProductoAlimenticio("Rocklets", 1370);
        rocklets.sellos.add(altoGrasas);
        rocklets.sellos.add(altoCalorias);
        rocklets.sellos.add(altoAzucares);

        ProductoAlimenticio donuts = new ProductoAlimenticio("Galletas Donuts", 749);
        donuts.sellos.add(altoGrasas);
        donuts.sellos.add(altoCalorias);
        donuts.sellos.add(altoAzucares);

        unimarc.addProducto(chocapic);
        unimarc.addProducto(trix);
        unimarc.addProducto(svelty);
        unimarc.addProducto(nido);
        unimarc.addProducto(mantequillaS);
        unimarc.addProducto(rocklets);
        unimarc.addProducto(donuts);

        System.out.println("Ganancias Totales: " + unimarc.totalGanancias());
        System.out.println("Precio Promedio: " + unimarc.precioPromedio());
        System.out.println("Precio Más Alto: " + unimarc.precioMasAlto());
        System.out.println("Precio Más Bajo: " + unimarc.precioMasBajo());
        System.out.println("----------");

        System.out.println("Productos libre de sellos:");
        ArrayList<ProductoAlimenticio> productos = unimarc.getProductosLibreDeSellos();
        for (int i = 0; i < productos.size(); i++) {
            System.out.println(productos.get(i).getNombre());
        }
        System.out.println("----------");

        System.out.println("Productos menos saludables:");
        productos = unimarc.getProductosMenosSaludables();
        for (int i = 0; i < productos.size(); i++) {
            System.out.println(productos.get(i).getNombre());
        }
        System.out.println("----------");

    }

}
