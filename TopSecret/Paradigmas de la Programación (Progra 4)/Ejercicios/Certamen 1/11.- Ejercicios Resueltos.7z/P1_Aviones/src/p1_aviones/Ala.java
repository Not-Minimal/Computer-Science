package p1_aviones;

public class Ala {

    private Avion avion;
    public boolean isEncendida;

    public Ala(Avion avion) {
        this.avion = avion;
    }

    public void encenderAla() {
        isEncendida = avion.consumirCombustible(30);
    }

}
