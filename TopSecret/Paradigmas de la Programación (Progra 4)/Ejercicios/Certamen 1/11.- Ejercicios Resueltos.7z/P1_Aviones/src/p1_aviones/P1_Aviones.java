package p1_aviones;

public class P1_Aviones {

    public static void main(String[] args) {

        Avion lan = new Avion(300);

        System.out.println("Encendiendo ala derecha...");
        lan.encenderAlaDer();

        System.out.println("¿Es posible volar? - " + lan.isListoVolar());

        System.out.println("Encendiendo ala izquierda...");
        lan.encenderAlaIzq();

        System.out.println("¿Es posible volar? - " + lan.isListoVolar());
    }

}
