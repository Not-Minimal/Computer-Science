package p1_aviones;

public class Avion {

    public String nombre;
    private int combustible;
    private Ala alaIzq;
    private Ala alaDer;

    public Avion(int combustible) {
        this.combustible = combustible;
        alaIzq = new Ala(this);
        alaDer = new Ala(this);
    }

    public void encenderAlaIzq() {
        alaIzq.encenderAla();
    }

    public void encenderAlaDer() {
        alaDer.encenderAla();
    }

    public boolean isListoVolar() {
        return alaIzq.isEncendida && alaDer.isEncendida;
    }

    public boolean consumirCombustible(int cantidad) {
        combustible -= cantidad;

        if (combustible < 0){
            combustible = 0;
            return false;
        }
        else 
            return true;
    }

}
