package p2_sistemasolar;

public class Planeta {
    
    protected String nombre;
    private long distanciaDeSol;
    
    public Planeta(String nombre, long distanciaDeSol)
    {
        this.nombre = nombre;
        this.distanciaDeSol = distanciaDeSol;
    }
    
    public Planeta(long distanciaDeSol)
    {
        this("Sin Definir", distanciaDeSol);
    }
    
    public long getDistanciaDeSol()
    {
        return distanciaDeSol;
    }
    
    public String getNombre()
    {
        return nombre;
    }
    
}
