package p2_sistemasolar;

import java.util.ArrayList;

public class SistemaSolar {

    protected ArrayList<Planeta> planetas;

    public SistemaSolar() {
        planetas = new ArrayList<>();
    }

    public void addPlaneta(String nombre, long distanciaDeSol) {
        Planeta nuevoPlaneta = new Planeta(nombre, distanciaDeSol);
        planetas.add(nuevoPlaneta);
    }

    public ArrayList<Planeta> getPlanetas() {
        return planetas;
    }

    public Planeta getPlanetaMasLejanoASol() {
        
        if(planetas.isEmpty()) return null;
        
        Planeta masLejano = planetas.get(0);

        for (int i = 1; i < planetas.size(); i++) {
            if (planetas.get(i).getDistanciaDeSol() > masLejano.getDistanciaDeSol()) {
                masLejano = planetas.get(i);
            }
        }

        return masLejano;
    }

    public Planeta getPlanetaMasCercanoASol() {
        
        if(planetas.isEmpty()) return null;
        
        Planeta masCercano = planetas.get(0);

        for (int i = 1; i < planetas.size(); i++) {
            if (planetas.get(i).getDistanciaDeSol() < masCercano.getDistanciaDeSol()) {
                masCercano = planetas.get(i);
            }
        }

        return masCercano;

    }

    public Planeta[] getArregloOrdenadoPorDistancia() {
        Planeta planetasOrden[] = new Planeta[planetas.size()];

        for (int i = 0; i < planetasOrden.length; i++) {
            planetasOrden[i] = planetas.get(i);
        }

        for (int i = 0; i < planetasOrden.length - 1; i++) {
            for (int j = i + 1; j < planetasOrden.length; j++) {
                if (planetasOrden[i].getDistanciaDeSol() > planetasOrden[j].getDistanciaDeSol()) {
                    Planeta aux = planetasOrden[i];
                    planetasOrden[i] = planetasOrden[j];
                    planetasOrden[j] = aux;
                }
            }
        }
        return planetasOrden;
    }

}
