package p2_sistemasolar;

public class P2_SistemaSolar {

    public static void main(String[] args) {

        SistemaSolar viaLactea = new SistemaSolar();

        viaLactea.addPlaneta("Júpiter"  , 778330000);
        viaLactea.addPlaneta("Tierra"   , 146600000);
        viaLactea.addPlaneta("Neptuno"  , 4504300000L);
        viaLactea.addPlaneta("Mercurio" , 57910000);
        viaLactea.addPlaneta("Marte"    , 227940000);
        viaLactea.addPlaneta("Urano"    , 2870990000L);
        viaLactea.addPlaneta("Saturno"  , 1429400000);
        viaLactea.addPlaneta("Venus"    , 108200000);

        System.out.println("Planeta más lejano al Sol: " + viaLactea.getPlanetaMasLejanoASol().getNombre());
        System.out.println("Planeta más cercano al Sol: " + viaLactea.getPlanetaMasCercanoASol().getNombre());

        System.out.println("Planetas ordenados:");
        Planeta planetas[] = viaLactea.getArregloOrdenadoPorDistancia();

        for (int i = 0; i < planetas.length; i++) {
            System.out.println(planetas[i].getNombre());
        }
    }

}
