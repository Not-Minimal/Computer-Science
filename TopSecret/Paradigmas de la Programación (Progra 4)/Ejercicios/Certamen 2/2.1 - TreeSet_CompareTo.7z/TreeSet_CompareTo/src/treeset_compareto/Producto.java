package treeset_compareto;

public class Producto implements Comparable<Producto> {

    private String idTracker;
    private String nombre;

    public Producto(String idTracker, String nombre) {
        this.idTracker = idTracker;
        this.nombre = nombre;
    }

    public String getIdTracker() {
        return idTracker;
    }

    @Override
    public int compareTo(Producto t) {//Recordar que String ya implementa su propio compareTo.
        return idTracker.compareTo(t.idTracker);
    }

    @Override
    public String toString() {
        return idTracker + " " + nombre;
    }

}
