package treeset_compareto;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSet_CompareTo {

    public static void main(String[] args) {
        TreeSet<Producto> productos = new TreeSet<>();

        productos.add(new Producto("TEC-20", "Xbox One S"));
        productos.add(new Producto("HOG-14", "Mueble Televisor"));
        productos.add(new Producto("TEC-10", "Laptop 14'"));
        productos.add(new Producto("TEC-50", "Disco Duro 1TB"));
        productos.add(new Producto("OFI-70", "Lapiz Tinta"));
        productos.add(new Producto("TEC-13", "Impresora Tinta"));
        productos.add(new Producto("TEC-1", "Smartphone"));

        // Imprimir por consola el listado de productos de forma ascendente.
        System.out.println("[Ascendente] Productos: " + productos);
        //Imprimir por consola el listado de productos de forma descendente.
        System.out.println("[Descendente]Productos: " + productos.descendingSet());
        //Imprima el primer producto almacenado y el último.
        System.out.println("Primer producto: " + productos.first());
        System.out.println("Último producto: " + productos.last());
        //Elimine el primer y último producto almacenado en el TreeSet.
        productos.remove(productos.first());
        productos.remove(productos.last());
        System.out.println("Nuevo Estado: " + productos);
        //Agregue una instancia con datos repetidos de otra. ¿Habrá algún problema?
        productos.add(new Producto("TEC-20", "Xbox One S")); //Esta instrucción será ignorada, ya que existe en TreeSet.
        //En el caso que haya un problema, ¿Cómo se puede solucionar?
        //La nueva instancia debe ser tener otro Id, diferente al resto que se encuentra almacenado.
        //Utilice los métodos floor y ceiling de la instancia de TreeSet. Indique el porqué de su comportamiento.
        System.out.println("[Floor] " + productos.floor(new Producto("TEC-10", "X")));
        //El método floor buscará una instancia de valor de comparación igual o menor más cercano.
        //En el caso que no lo encuentre retornará NULL.
        System.out.println("[Ceiling] " + productos.ceiling(new Producto("TEC-10", "")));
        //El método ceiling buscará una instancia de valor de comparación igual o mayor más cercano.
        //En el caso que no lo encuentre retornará NULL.

        //Utilice los métodos headSet y tailSet de la instancia de TreeSet. Indique el porqué de su comportamiento.
        //Obteniedo valor de 14 Mueble Televisor.
        Producto mueble = productos.ceiling(new Producto("TEC-10", ""));
        //El valor false indica que el producto no debe ser incluído en la lista
        System.out.println("[headSet] " + productos.headSet(mueble, false));//Entrega el lista que se encuentra antes que el producto
        System.out.println("[tailSet] " + productos.tailSet(mueble, false));//Entrega el listado que se encuentra después que el producto

        //Elimine del TreeSet todos los productos que comiencen con X valor en su idTracker. 
        //(Revisar Iterator y método startsWith de String).
        //Todos los productos que inicien con TEC serán borrados.
        Iterator<Producto> e = productos.iterator();

        while (e.hasNext()) {
            Producto p = e.next();
            if (p.getIdTracker().startsWith("TEC")) {
                e.remove();
            }
        }

        System.out.println("Lista sin TEC: " + productos);
    }

}
