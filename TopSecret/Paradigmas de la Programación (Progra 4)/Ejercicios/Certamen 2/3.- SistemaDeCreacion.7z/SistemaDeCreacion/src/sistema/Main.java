package sistema;

public class Main {

    public static void main(String[] args) {

        SistemaCreacion sistema = new SistemaCreacion();
        CreadorAyudante ayudante = new CreadorAyudante();

        sistema.agregarMaterial(MaterialTipo.LANA, 5);
        sistema.agregarMaterial(MaterialTipo.AGUA, 2);
        sistema.agregarMaterial(MaterialTipo.MADERA, 10);
        sistema.agregarMaterial(MaterialTipo.PIEDRA, 5);
        sistema.agregarMaterial(MaterialTipo.HARINA, 1);

        int fallos = 0;
        fallos += ayudante.crearProducto(sistema, ProductoTipo.SILLA);
        fallos += ayudante.crearProducto(sistema, ProductoTipo.REFUGIO);
        fallos += ayudante.crearProducto(sistema, ProductoTipo.GORRO);
        fallos += ayudante.crearProducto(sistema, ProductoTipo.SILLA);
        fallos += ayudante.crearProducto(sistema, ProductoTipo.PAN);

        System.out.println("Cantidad de veces sin materiales: " + fallos);
        System.out.println("Materiales sobrantes:\n" + sistema);
    }

}
