package series;

import java.util.TreeSet;

public class GestorSeries {

    private final TreeSet<Serie> series;

    public GestorSeries() {
        series = new TreeSet<>();
    }

    public void addSerie(String nombre, int temporada) {
        series.add(new Serie(nombre, temporada));
    }

    @Override
    public String toString() {
        String texto = "";

        for (Serie item : series)
            texto += item.getNombre() + " - " + item.getTemporada() + "\n";

        return texto;
    }
}
