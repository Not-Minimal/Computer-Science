package geometria;

public class Triangulo implements IArea {

    private float base;
    private float altura;

    public Triangulo(float base, float altura) {
        this.base = base;
        this.altura = altura;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    @Override
    public double getArea() {
        return (base * altura) / 2;
    }

    @Override
    public int compareTo(IArea t) {
        if (getArea() > t.getArea())
            return 1;
        if (getArea() < t.getArea())
            return -1;
        return 0;
    }

}
