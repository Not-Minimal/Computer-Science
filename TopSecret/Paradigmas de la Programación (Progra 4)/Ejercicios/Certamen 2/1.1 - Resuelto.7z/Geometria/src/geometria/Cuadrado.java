package geometria;

public class Cuadrado implements IArea {

    private float lado;

    public Cuadrado(float lado) {
        this.lado = lado;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    @Override
    public double getArea() {
        return lado * lado;
    }

    @Override
    public int compareTo(IArea t) {
        if (getArea() > t.getArea())
            return 1;
        if (getArea() < t.getArea())
            return -1;
        return 0;
    }

}
