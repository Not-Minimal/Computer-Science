package geometria;

public class Circulo implements IArea {

    private float radio;

    public Circulo(float radio) {
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    @Override
    public double getArea() {
        return Math.PI * radio * radio;
    }

    @Override
    public int compareTo(IArea t) {
        if (getArea() > t.getArea())
            return 1;
        if (getArea() < t.getArea())
            return -1;
        return 0;
    }

}
