package geometria;

public class Geometria {

    public static void main(String[] args) {

        GestorFiguras gestor = new GestorFiguras();
        gestor.addFigura(new Circulo(5));
        gestor.addFigura(new Rectangulo(1, 2));
        gestor.addFigura(new Cuadrado(10));
        gestor.addFigura(new Triangulo(4, 15));
        gestor.addFigura(new Circulo(1));
        gestor.addFigura(new Rectangulo(5, 5));
        gestor.addFigura(new Cuadrado(7));
        gestor.addFigura(new Triangulo(20, 20));

        System.out.println("Suma Total(Áreas): " + gestor.totalAreas());
        System.out.println("Menor área: " + gestor.menorArea());
        System.out.println("Mayor área: " + gestor.mayorArea());
        System.out.println("Áreas:\n" + gestor);

    }

}
