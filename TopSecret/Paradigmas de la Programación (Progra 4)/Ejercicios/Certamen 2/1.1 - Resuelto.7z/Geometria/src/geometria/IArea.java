package geometria;

public interface IArea extends Comparable<IArea>{

    public double getArea();

}
