package geometria;

import java.util.ArrayList;
import java.util.Collections;

public class GestorFiguras {

    private final ArrayList<IArea> areas;

    public GestorFiguras() {
        areas = new ArrayList<>();
    }

    public void addFigura(IArea figura) {
        areas.add(figura);
        Collections.sort(areas);
    }

    public double menorArea() {
        return areas.get(0).getArea();
    }

    public double mayorArea() {
        return areas.get(areas.size() - 1).getArea();
    }

    public double totalAreas() {

        double total = 0;

        for (IArea item : areas) {
            total += item.getArea();
        }

        return total;
    }

    @Override
    public String toString() {
        String texto = "";

        for (IArea item : areas) {
            texto += item.getArea() + "\n";
        }

        return texto;
    }
}
