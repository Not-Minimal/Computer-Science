package geometria;

public class Rectangulo implements IArea {

    private float base;
    private float lado;

    public Rectangulo(float base, float lado) {
        this.base = base;
        this.lado = lado;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    @Override
    public double getArea() {
        return base * lado;
    }

    @Override
    public int compareTo(IArea t) {
        if (getArea() > t.getArea())
            return 1;
        if (getArea() < t.getArea())
            return -1;
        return 0;
    }

}
