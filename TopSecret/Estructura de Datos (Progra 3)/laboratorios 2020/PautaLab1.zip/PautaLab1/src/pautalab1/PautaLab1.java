/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pautalab1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author Oscar
 */
public class PautaLab1 {

    
    public int PrimerCuartil(int[] vector){
        int r = 0;
        if(vector.length % 2 == 0){
            r = (25*vector.length)/100;
            return (vector[r] + vector[r-1])/2; 
        }
        r = (25*vector.length)/100;
        return vector[r];
    }
    
    public int TercerCuartil(int[] vector){
        int r = 0;
        if(vector.length % 2 == 0){
            r = (75*vector.length)/100;
            return (vector[r] + vector[r-1])/2; 
        }
        r = (75*vector.length)/100;
        return vector[r];
    }
    
    public int Mediana(int[] vector){
        int med = 0;
        if(vector.length % 2 == 0){
            med = (vector[vector.length/2] + vector[(vector.length/2) - 1]) / 2;
        }else med = vector[vector.length/2];
        return med;
    }
    
    public void MayMenIgual(int[] vector, float prom){
        int mayores = 0;
        int menores = 0;
        int iguales = 0;
        //int promedio = Promedio(vector);
        for(int i=0;i<vector.length;i++){
            if(vector[i] > prom){
                mayores++;
            }else if(vector[i] < prom){
                menores++;
            }else iguales ++;
        }
        System.out.println("#Mayores = "+mayores+"\n#Menores = "+menores+"\n#Iguales = "+iguales);
    }
    
    public float Promedio(int[] vector){
        float prom = 0;
        for(int i=0;i<vector.length;i++){
            prom = prom + vector[i];
        }
        return (prom/vector.length);
    }
    
    public void Burbuja(int[] elementos){
        for(int i = 0;i<elementos.length;i++){
            for(int j=0;j<(elementos.length - i) - 1; j++){
                if(elementos[j] > elementos[j+1]){
                    int swap = elementos[j];
                    elementos[j] = elementos[j+1];
                    elementos[j+1] = swap;
                }
            }
        }
    }

    public static void main(String[] args) {
        PautaLab1 a = new PautaLab1();
        BufferedReader br = null;
        int n = 0;
	System.out.print("Ingrese dimension del vector: ");
        try{
           br = new BufferedReader(new InputStreamReader(System.in));
           n =Integer.parseInt(br.readLine());
           br.close();
        }
        catch(IOException | NumberFormatException e){System.exit(1);}
        int[] vector = new int[n];        
        try{
            Random rnd = new Random();
            for(int i=0;i<n;i++){
                vector[i] = rnd.nextInt(n)+1;
            }
        }catch(Exception e){}
        int[] aux = vector.clone();
        a.Burbuja(aux);
        float prom = a.Promedio(vector);
        System.out.println("Promedio = "+prom+"\nMediana = "+a.Mediana(aux)+"\nPrimer Cuartil = "+a.PrimerCuartil(aux)+"\nTercer Cuartil = "+a.TercerCuartil(aux));
        a.MayMenIgual(aux, prom);
    }
  
}
