/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test2;

/**
 *
 * @author Oscar
 */
public class PilaDinamica {
    public Nodo tope;

    public PilaDinamica(){
            tope = null;
    }

    public boolean empty(){
        return tope == null;
    }

    public int peek() {
        return !empty() ? tope.elemento : -1;
    }

    public void push(int elemento){
        Nodo nuevo = new Nodo(elemento);
        if(empty()){
            tope = nuevo;
        }
        else{
            nuevo.sig = tope;
            tope = nuevo;
        }
    }

    public void pop(){
		if(!empty()){
			tope = tope.sig;
		}
    }

	@Override
    public String toString(){
        PilaDinamica o = new PilaDinamica();
        String salida = "Tope:";
        while(!empty()){
            salida += peek() + "->";
            o.push(peek());
            pop();
        }
        while(!o.empty()){
            push(o.peek());
            o.pop();
        }
        return salida;
    }

    public void pushOrdenado(int x){
        //ESCRIBA SU CÓDIGO AQUI
        if(empty()){
            push(x);
        }
        else{
            PilaDinamica aux1 = new PilaDinamica();
            int a=0;
            while(!empty() && a==0){
                if(peek()<x){
                    a=1;
                }
                else{
                    aux1.push(peek());
                    pop();
                }
            }
            aux1.push(x);
            while(!aux1.empty()){
                push(aux1.peek());
                aux1.pop();
            }
        }
    }

    public void invertir(){
        //ESCRIBA SU CÓDIGO AQUI
        PilaDinamica aux1 = new PilaDinamica();
        PilaDinamica aux2 = new PilaDinamica();
        while(!empty()){
        	aux1.push(peek());
        	pop();
        }
        while(!aux1.empty()){
        	aux2.push(aux1.peek());
        	aux1.pop();
        }
        while(!aux2.empty()){
        	push(aux2.peek());
        	aux2.pop();
        }
    }
}
