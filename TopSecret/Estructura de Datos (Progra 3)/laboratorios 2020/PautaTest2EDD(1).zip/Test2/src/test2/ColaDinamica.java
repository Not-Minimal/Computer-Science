/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test2;

/**
 *
 * @author Oscar
 */
public class ColaDinamica {
    public Nodo inicio;
	public Nodo fin;

	public ColaDinamica(){
		inicio = null;
		fin = null;
	}

	public boolean empty(){
        return inicio == null;
    }

    public int seekStart(){
        return !empty() ? inicio.elemento : -1;
    }

	public void encolar(int elemento){
        Nodo nuevo = new Nodo(elemento);
		if(empty()){
            inicio = nuevo;
            fin = nuevo;
        }
        else{
            fin.sig = nuevo;
            fin = nuevo;
        }
    }

    public void desencolar(){
		if(!empty()){ 
			inicio = inicio.sig;
		}
    }

    public String toString(){
		ColaDinamica o = new ColaDinamica();
		String salida = "Inicio:";
        while(!empty()){
            salida += seekStart() + "->";
            o.encolar(seekStart());
            desencolar();
        }
        while(!o.empty()){
            encolar(o.seekStart());
            o.desencolar();
        }
        return salida;
    }

    public void mantenerPares(){
        //ESCRIBA SU CÓDIGO AQUI
        ColaDinamica aux1 = new ColaDinamica();
        while(!empty()){
            if(seekStart()%2==0){
                aux1.encolar(seekStart());
            }
            desencolar();
        }
        while(!aux1.empty()){
            encolar(aux1.seekStart());
            aux1.desencolar();
        }
    }

    public void reemplazar(int original, int reemplazo){
        //ESCRIBA SU CÓDIGO AQUI
        ColaDinamica aux1 = new ColaDinamica();
        while(!empty()){
            if(seekStart()==original){
                aux1.encolar(reemplazo);
            }
            else{
                aux1.encolar(seekStart());
            }
            desencolar();
        }
        while(!aux1.empty()){
            encolar(aux1.seekStart());
            aux1.desencolar();
        }
    }
}
