/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;


public class Lab5{
	public static void main(String[] args){
		ListaDoble uno = new ListaDoble();
		ListaDoble dos = new ListaDoble();
		String ans;
		uno.insertarFinal(1);
		uno.insertarFinal(2);
		uno.insertarFinal(3);
		dos.insertarInicio(3);
		dos.insertarInicio(2);
		dos.insertarInicio(1);
		System.out.println("Lista 1: "+uno);
		System.out.println("Lista 2: "+dos);
		ans = uno.equals(dos) ? "Son iguales" : "No son iguales";
		System.out.println(ans);
		//ans = uno.encontrar(2) ? "Lista 1 contiene 2" : "Lista 1 no contiene 2";
		System.out.println(ans);
		//ans = dos.encontrar(4) ? "Lista 2 contiene 4" : "Lista 2 no contiene 4";
		System.out.println(ans);
		//dos.eliminar(2);
		System.out.println("Lista 1: "+uno);
		System.out.println("Lista 2: "+dos);
		ans = uno.equals(dos) ? "Son iguales" : "No son iguales";
		System.out.println(ans);
	}
	
}
