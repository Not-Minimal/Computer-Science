/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author Oscar
 */
//
//->1->2->3->4->
//<-1<-2<-3<-4<-
public class NodoDoble {
    int elemento;
    NodoDoble ant;
    NodoDoble sig;

    public NodoDoble(int x){
        //Constructor del NodoDoble
        elemento = x;
        ant = null;
        sig = null;
    }

    public String toString(){
            return elemento+"<-->";
    }

    public boolean equals(Object o){
            if(o instanceof NodoDoble){
                    return elemento == ((NodoDoble)o).elemento;
            }
            else return false;
    }
}
