/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author Oscar
 */
public class ListaDoble {
    NodoDoble inicio;
    NodoDoble fin;

    public ListaDoble(){
           //Constructor de ListaDoble
        inicio = null;
	fin = null;
    }

    public void insertarFinal(int x){
        //inserta al final de la lista
        NodoDoble nuevo = new NodoDoble(x);
        if(inicio == null){
                inicio = nuevo;
                fin = nuevo;
        }
        else{
                nuevo.ant = fin;
                fin.sig = nuevo;
                fin = nuevo;
        }
    }

    public void insertarInicio(int x){
        //inserta al inicio de la lista
        NodoDoble nuevo = new NodoDoble(x);
        if(inicio == null){
                inicio = nuevo;
                fin = nuevo;
        }
        else{
                inicio.ant = nuevo;
                nuevo.sig = inicio;
                inicio = nuevo;
        }
    }

    public void insertarDespues(int x, int despuesDe){
        //inserta despues del elemento despuesDe
        //->1->2->3
        //4 2
        //->1->2->4->3->
        NodoDoble nuevo = new NodoDoble(x);
        if(inicio == null){
                inicio = nuevo;
                fin = nuevo;
        }
        else{
                NodoDoble paso = inicio;
                while(paso.sig!=null){
                        if(paso.elemento == despuesDe){
                                nuevo.ant = paso;
                                nuevo.sig = paso.sig;
                                paso.sig.ant = nuevo;
                                paso.sig = nuevo;
                                return;
                        }
                        else{
                                paso = paso.sig;
                        }
                }
                //fin
                if(fin.elemento == despuesDe){
                        nuevo.ant = fin;
                        fin.sig = nuevo;
                        fin = nuevo;
                }
        }
    }

    public void insertarAntes(int x, int antesDe){
        //inserta antes del elemento antesDe
        NodoDoble nuevo = new NodoDoble(x);
        if(inicio == null){
                inicio = nuevo;
                fin = nuevo;
        }
        else{
                if(inicio.elemento == antesDe){
                        inicio.ant = nuevo;
                        nuevo.sig = inicio;
                        inicio = nuevo;
                }
                else{
                        NodoDoble paso = inicio.sig;
                        while(paso!=null){
                                if(paso.elemento == antesDe){
                                        nuevo.ant = paso.ant;
                                        nuevo.sig = paso;
                                        paso.ant.sig = nuevo;
                                        paso.ant = nuevo;
                                        return;
                                }
                                else{
                                        paso = paso.sig;
                                }
                        }
                }
        }
    }

    public boolean encontrar(int x){
        //busca un elemento x dentro de la lista
        NodoDoble paso = inicio;
        while(paso!=null){
                if(paso.elemento == x)
                        return true;
                else paso = paso.sig;
        }
        return false;
    }

    public boolean eliminar(int x){
        //elimina el elemento x
        if(inicio.elemento == x){
                inicio = inicio.sig;
                inicio.ant=null;
                return true;
        }
        else{
                NodoDoble paso = inicio.sig;
                while(paso.sig!=null){
                        if(paso.elemento == x){
                                paso.ant.sig = paso.sig;
                                paso.sig.ant = paso.ant;
                                return true;
                        }
                        else{
                                paso = paso.sig;
                        }
                }
                //fin
                if(fin.elemento == x){
                        fin = fin.ant;
                        fin.sig=null;
                        return true;
                }
        }
        return false;
    }

    @Override
    public String toString(){
        String salida = "";
        NodoDoble paso = inicio;
        while(paso!=null){
                salida += paso;
                paso = paso.sig;
        }
        salida += "\n";
        paso = fin;
        while(paso!=null){
                salida += paso;
                paso = paso.ant;
        }
        return salida;
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof ListaDoble){
                NodoDoble paso1 = inicio;
                NodoDoble paso2 = ((ListaDoble)o).inicio;
                while(paso1!=null && paso2!=null){
                        if(!paso1.equals(paso2)) return false;
                        paso1 = paso1.sig;
                        paso2 = paso2.sig;
                }
                return paso1==null && paso2==null;
        }
        else return false;
    }
}
